 // fun(eve:FileList) {
import { Component,Inject, OnInit } from '@angular/core';
import { Http,Response } from '@angular/http';
import { MatCardModule } from '@angular/material';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material';
@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',  
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  // bikes = ['Pulsar 220','Pulsar 250','Pulsar 150','Pulsar 180','Duke','KTM Suzuki','fz','royal enfield','glamour',
  //   'scooty','honda shine'];
  constructor(public dialog: MatDialog,public http:Http) { }
  fs(file) {
    console.log(file.target);
  }  
  upload() {
    
  }
  
  ngOnInit() {
    }
}
  